package com.cts.springBootJDBC;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.sql.Connection;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;



@SpringBootTest
public class MenuItemDaoTest {

	@Autowired
	MenuItemDao menuItemDao;
	@Autowired
	JdbcTemplate jdb;

	@Test

	void testGetMenuList() {
		// Resource resource = new ClassPathResource("applicationContext.xml");

		// BeanFactory factory = new XmlBeanFactory(resource);

		// MenuItemDao menuItemDao = (MenuItemDao) factory.getBean("MenuObj");

		
		List<MenuItem> l = menuItemDao.getMenuList();

		Assertions.assertEquals(4, l.size());

	}

	@Test

	void testGetConnection() {

		// Resource resource = new ClassPathResource("applicationContext.xml");

		// BeanFactory factory = new XmlBeanFactory(resource);

		// MenuItemDao menuItemDao = (MenuItemDao) factory.getBean("MenuObj");


		Connection c = menuItemDao.getConnection();

		assertNotNull(c);

	}
	
	@Test

	void testJDBCTemplate() {

		// ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(

		//		"applicationContext.xml");

		// JdbcTemplate jdb = (JdbcTemplate) context.getBean("jdbcTemplate");

		List<MenuItem> l = menuItemDao.getMenuListJDBCTemplate();

		Assertions.assertEquals(4, l.size());


	}


}
