package com.cts.springBootJDBC;

import java.util.List;

public interface CartDao {
	void addCartItem(long userId, long menuItemId);

	List<Integer> getAllCartItems(int userId);

	void removeCartItem(long userId, long menuItemId);

}
