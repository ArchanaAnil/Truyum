package com.cts.springBootJDBC.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.cts.springBootJDBC.CartDaoImpl;
import com.cts.springBootJDBC.MenuItem;
import com.cts.springBootJDBC.MenuItemDao;

@Controller
@SessionAttributes("username")
public class SpringBootJdbcController {

	@Autowired
	MenuItemDao menuItemDao;

	@Autowired
	CartDaoImpl cartDaoImpl;

	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public String getMenuItemListUser(ModelMap model) {
		model.put("menulist", menuItemDao.getMenuListJDBCTemplate());
		return "menu-list-item";

	}

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String UserHomepage(ModelMap model) {
		model.put("menulist", menuItemDao.getMenuListJDBCTemplate());
		return "user";

	}

	@RequestMapping(value = "/index")
	public String Homepage(ModelMap model) {
		model.put("menulist", menuItemDao.getMenuListJDBCTemplate());
		return "index";
	}

	@RequestMapping(value = "/admin")
	public String AdminHomepage(ModelMap model) {
		model.put("menulist", menuItemDao.getMenuListJDBCTemplate());
		return "admin";
	}
	

	@RequestMapping(value = "/edit-menu", method = RequestMethod.GET)
	public String edit(ModelMap model, @RequestParam int id) {
	// List<MenuItem> list = menuItemDaoImpl.getMenuItemListAdmin();
	// MenuItem menuItem = menuItemDaoImpl.retreiveMenuItem(id);
	List<MenuItem> list = menuItemDao.getMenuListJDBCTemplate();
	MenuItem menuItem = new MenuItem();
	for (MenuItem ele : list) {
	if (ele.getId() == id) {
	menuItem = ele;
	}
	}
	model.put("menuItem", menuItem);
	model.put("id", id);
	System.out.println(id);
	return "edit-menu";
	}

	
	@RequestMapping(value = "/edit-menu", method = RequestMethod.POST)
	public String EditMenuSuccess(ModelMap model, @RequestParam int id, @RequestParam String iname, @RequestParam float price) {
		// menuItemDao.editMenuItem(name, price, id);
		// List<MenuItem> list = menuItemDao.getMenuListJDBCTemplate();
		MenuItem menuItem = new MenuItem();
		menuItem.setId(id);
		menuItem.setName(iname);
		menuItem.setPrice(price);
		menuItemDao.editMenuItem(iname,price,id);
		return "edit-menu-item-success";
	}
	
	


	@RequestMapping(value = "/login")
	public String Login() {

		return "login";
	}

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public String SignupUser(ModelMap model) {
		model.put("menulist", menuItemDao.getMenuListJDBCTemplate());
		return "user";
	}

	@RequestMapping(value = "/signup")
	public String Signup() {
		return "signup";
	}

	@RequestMapping(value = "/admin", method = RequestMethod.POST)
	public String AdminLogin(ModelMap model) {
		model.put("menulist", menuItemDao.getMenuListJDBCTemplate());
		return "admin";
	}

	@RequestMapping("/logout")
	public String logOut(SessionStatus status) {
		status.setComplete();
		return "redirect:/login";
	}

	@RequestMapping("/add-cart")
	public String addToCart(ModelMap model, @RequestParam int id) {
		String name = (String) model.get("username");
		// int us_id = loginValidadtion.getUserId(name);
		// List<MenuItem> list = menuItemDaoImpl.getMenuItemListAdmin();
		// MenuItem menuItem = new MenuItem();
		// for(MenuItem ele : list) {
		// if(ele.getId() == id) {
		// menuItem = ele;
		// }
		// }
		cartDaoImpl.addCartItem(2, id);
		List<MenuItem> list = menuItemDao.getMenuListJDBCTemplate();
		MenuItem menuItem = new MenuItem();
		for (MenuItem ele : list) {
			if (ele.getId() == id) {
				menuItem = ele;
			}
		}
		String str = menuItem.getName() + " added successfully!";
		model.put("itemId", id);
		model.put("username", name);
		model.put("list", list);
		model.put("message", str);
		return "add-cart";
	}

	@RequestMapping("/view-cart")
	public String viewCart(ModelMap model) {
		String name = (String) model.get("username");
		//int us_id = loginValidadtion.getUserId(name);
		List<Integer> list = cartDaoImpl.getAllCartItems(2);
		List<MenuItem> cartItem = new ArrayList<>();
		double total = 0;
		for (Integer ele : list) {
			List<MenuItem> listTemp = menuItemDao.getMenuListJDBCTemplate();
			for (MenuItem m : listTemp) {
				if (m.getId() == ele) {
					cartItem.add(m);
					total += m.getPrice();
				}
			}
		}
		model.put("list", cartItem);
		model.put("total", total);
		return "viewCart";
	}
	
	@RequestMapping("/viewcart")
	public String viewCartAfterDelete(ModelMap model, @RequestParam int id) {
		String name = (String) model.get("username");
		//int us_id = loginValidadtion.getUserId(name);
		cartDaoImpl.removeCartItem(2,id);
		List<Integer> list = cartDaoImpl.getAllCartItems(2);
		List<MenuItem> cartItem = new ArrayList<>();
		double total = 0;
		for (Integer ele : list) {
			List<MenuItem> listTemp = menuItemDao.getMenuListJDBCTemplate();
			for (MenuItem m : listTemp) {
				if (m.getId() == ele) {
					cartItem.add(m);
					total += m.getPrice();
				}
			}
		}
		model.put("list", cartItem);
		model.put("total", total);
		return "viewCart";
	}
	
	
	

}
