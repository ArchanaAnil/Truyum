package com.cts.springBootJDBC;



import java.sql.ResultSet;

import java.sql.SQLException;



import org.springframework.jdbc.core.RowMapper;



public class MenuMapper  implements RowMapper<MenuItem> {



	@Override

	public MenuItem mapRow(ResultSet rs, int rowNum) throws SQLException {

		MenuItem menu = new MenuItem();

		menu.setName(rs.getString(2));

		menu.setId(rs.getLong(1));
		menu.setPrice(rs.getFloat(3));
		menu.setActive(rs.getString(4));
		menu.setDateOfLaunch(rs.getDate(5));
		menu.setCategory(rs.getString(6));
		menu.setFreeDelivery(rs.getString(7));
		menu.setImg_url(rs.getString(8));
		return menu;

	}



}