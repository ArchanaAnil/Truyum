package com.cts.springBootJDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MenuItemDao {
	
	@Autowired
	JdbcTemplate jdb;

	public Connection getConnection() {

		Connection con = null;

		try {

			con = DriverManager.

					getConnection("jdbc:mysql://localhost:3306/truyum", "root", "Priyaanil@123");

		} catch (SQLException e1) {

			e1.printStackTrace();

		}

		return con;

	}

	public List<MenuItem> getMenuList() {

		Connection con = getConnection();
		Statement st = null;
		List<MenuItem> mList = new ArrayList<>();
		try {

			st = con.createStatement();

			ResultSet rs = st.executeQuery("select * from menu_item");

			while (rs.next()) {

				System.out.println(rs.getInt(1));

				System.out.println(rs.getString(2));

				System.out.println(rs.getFloat(3));

				MenuItem menu = new MenuItem();

				menu.setName(rs.getString(2));

				menu.setId(rs.getLong(1));
				menu.setPrice(rs.getFloat(3));
				menu.setActive(rs.getString(4));
				menu.setDateOfLaunch(rs.getDate(5));
				menu.setCategory(rs.getString(6));
				menu.setFreeDelivery(rs.getString(7));
				menu.setImg_url(rs.getString(8));
				mList.add(menu);

			}

		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			try {

				con.close();

				st.close();

			} catch (SQLException e) {

				e.printStackTrace();

			}
		}

		return mList;
	}

	public List<MenuItem> getMenuListJDBCTemplate() {
		String sql = "select * from menu_item";
		List<MenuItem> list = jdb.query(

				sql, new MenuMapper());
		for(MenuItem l : list)
		{
			System.out.println(l.getName());
		}
		return list;

	}
	
	
	public void editMenuItem(String iname, float price,long id)
	{
		
		//String name=menuItem.getName();
		//float price= menuItem.getPrice();
		//long id=menuItem.getId();
		String sql="update menu_item"+" set me_name=? ,"+" me_price=?" + " where me_id=?";
		jdb.update(sql,iname,price,id);
		
	}
	
}
