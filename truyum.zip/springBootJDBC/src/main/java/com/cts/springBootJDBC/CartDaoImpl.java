package com.cts.springBootJDBC;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class CartDaoImpl implements CartDao{

@Autowired
JdbcTemplate jdbc;
@Autowired
CartMapper mapper;

@Override
public void addCartItem(long userId, long menuItemId) {
String sql = "insert into cart(ct_us_id, ct_pr_id) values(?,?)";
jdbc.update(sql,userId, menuItemId);
}

@Override
public List<Integer> getAllCartItems(int userId) {
String sql = "select ct_pr_id from cart where ct_us_id = ?";
List<Integer> list = jdbc.query(sql, mapper, userId);
return list;
}

@Override
public void removeCartItem(long userId, long menuItemId) {

	String sql = "delete from cart where ct_us_id=? and ct_pr_id=? ";
	jdbc.update(sql,userId,menuItemId);
}

}
