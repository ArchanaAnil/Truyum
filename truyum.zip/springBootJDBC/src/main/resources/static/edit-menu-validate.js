function validateForm() {
            var x = document.forms["myForm"]["iname"].value;
            if (x == "") {
                var x = document.getElementById("error").innerHTML=" Item Name is Mandatory!!";
                return false;
            }
            else if(x.length > 200)
            {
                var x = document.getElementById("error").innerHTML="Max limit of Item Name is 200 characters!!";
                return false;
            }

            var y = document.forms["myForm"]["dateofLaunch"].value;
            if (y == "") {
                var y = document.getElementById("date-error").innerHTML=" Date is required!!";
                return false;
            }

            var z = document.forms["myForm"]["price"].value;
            if (z == "") {
                var z = document.getElementById("date-error").innerHTML=" Date is required!!";
                return false;
            }

            return true;
        }